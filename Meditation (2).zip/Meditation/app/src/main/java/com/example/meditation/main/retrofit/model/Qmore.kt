package com.example.meditation.main.retrofit.model

data class Qmore(
    val id : Int,
    val title : String,
    val image : String,
    val description : String
)
