package com.example.meditation.main.retrofit.util

class Constants {

    companion object{
        const val BASE_URL = "http://mskko2021.mad.hakta.pro/api"
    }
}