package com.example.meditation.main.retrofit.model

data class Quotes(
    val success : Boolean,
    val data : List<Qmore>
)
